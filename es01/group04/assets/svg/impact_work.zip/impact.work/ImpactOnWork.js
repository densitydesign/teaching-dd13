$(document).ready(function() {
  
    
    
$("#China").fadeTo(20,0.4);    
  $("#ChinaPopUp").hide();
    $("#China").hover(function() {
    $(this).toggleClass("ChinaPopUp");
        $("#ChinaPopUp").fadeToggle(20);
        $("#China").fadeTo(20,1);
        
    }, function () {
        $("#China").fadeTo(20,0.4);
        $("#ChinaPopUp").fadeToggle(20);
    });
    
            
    $("#India").fadeTo(20,0.4);         
     $("#IndiaPopUp").hide();
   $("#India").hover(function() {
    //toggle classe effetto
    $("#IndiaPopUp").fadeToggle(20);
        $("#India").fadeTo(20,1);
        
    }, function () {
        $("#India").fadeTo(20,0.4);
        $("#IndiaPopUp").fadeToggle(20);
    });
    
    
    $("#Oman").fadeTo(20,0.4);
    $("#OmanPopUp").hide();
     $("#Oman").hover(function() {
       $("#OmanPopUp").fadeToggle(20);
        $("#Oman").fadeTo(20,1);
        
    }, function () {
        $("#Oman").fadeTo(20,0.4);
        $("#OmanPopUp").fadeToggle(20);
    });
    
    $("#Kuwait").fadeTo(20,0.4);
    $("#KuwaitPopUp").hide();
     $("#Kuwait").hover(function() {
       $("#KuwaitPopUp").fadeToggle(20);
        $("#Kuwait").fadeTo(20,1);
        
    }, function () {
        $("#Kuwait").fadeTo(20,0.4);
        $("#KuwaitPopUp").fadeToggle(20);
    });
    
    
    $("#Greece").fadeTo(20,0.4);
      $("#GreecePopUp").hide();
     $("#Greece").hover(function() {
        $("#GreecePopUp").fadeToggle(20);
        $("#Greece").fadeTo(20,1);
        
    }, function () {
        $("#Greece").fadeTo(20,0.4);
        $("#GreecePopUp").fadeToggle(20);
    });
    
    
    $("#USA").fadeTo(20,0.4);
      $("#USAPopUp").hide();
     $("#USA").hover(function() {
       $("#USAPopUp").fadeToggle(20);
        $("#USA").fadeTo(20,1);
        
    }, function () {
        $("#USA").fadeTo(20,0.4);
        $("#USAPopUp").fadeToggle(20);
    });
     
    
    $("#UnitedArabEmirates").fadeTo(20,0.4);
      $("#UnitedArabEmiratesPopUp").hide();
     $("#UnitedArabEmirates").hover(function() {
   $("#UnitedArabEmiratesPopUp").fadeToggle(20);
        $("#UnitedArabEmirates").fadeTo(20,1);
        
    }, function () {
        $("#UnitedArabEmirates").fadeTo(20,0.4);
        $("#UnitedArabEmiratesPopUp").fadeToggle(20);
    });
        
    
      $("#Sweden").fadeTo(20,0.4);
       $("#SwedenPopUp").hide();
     $("#Sweden").hover(function() {
       $("#SwedenPopUp").fadeToggle(20);
        $("#Sweden").fadeTo(20,1);
        
    }, function () {
        $("#Sweden").fadeTo(20,0.4);
        $("#SwedenPopUp").fadeToggle(20);
    });
    
    
    $("#Chile").fadeTo(20,0.4);
     $("#ChilePopUp").hide();    
  $("#Chile").hover(function() {
    $("#ChilePopUp").fadeToggle(20);
        $("#Chile").fadeTo(20,1);
        
    }, function () {
        $("#Chile").fadeTo(20,0.4);
        $("#ChilePopUp").fadeToggle(20);
    });
    
    
     $("#Netherlands").fadeTo(20,0.4);
     $("#NetherlandsPopUp").hide();
   $("#Netherlands").hover(function() {
    $("#NetherlandsPopUp").fadeToggle(20);
        $("#Netherlands").fadeTo(20,1);
        
    }, function () {
        $("#Netherlands").fadeTo(20,0.4);
        $("#NetherlandsPopUp").fadeToggle(20);
    });
    
    
     $("#Australia").fadeTo(20,0.4);
    $("#AustraliaPopUp").hide();
     $("#Australia").hover(function() {
      $("#AustraliaPopUp").fadeToggle(20);
        $("#Australia").fadeTo(20,1);
        
    }, function () {
        $("#Australia").fadeTo(20,0.4);
        $("#AustraliaPopUp").fadeToggle(20);
    });
    
     $("#Malaysia").fadeTo(20,0.4);
      $("#MalaysiaPopUp").hide();
     $("#Malaysia").hover(function() {
     $("#MalaysiaPopUp").fadeToggle(20);
        $("#Malaysia").fadeTo(20,1);
        
    }, function () {
        $("#Malaysia").fadeTo(20,0.4);
        $("#MalaysiaPopUp").fadeToggle(20);
     });
    
    
    $("#Poland").fadeTo(20,0.4);
      $("#PolandPopUp").hide();
     $("#Poland").hover(function() {
        $("#PolandPopUp").fadeToggle(20);
        $("#Poland").fadeTo(20,1);
        
    }, function () {
        $("#Poland").fadeTo(20,0.4);
        $("#PolandPopUp").fadeToggle(20);
     });
    
      $("#Canada").fadeTo(20,0.4);
      $("#CanadaPopUp").hide();
     $("#Canada").hover(function() {
     $("#CanadaPopUp").fadeToggle(20);
        $("#Canada").fadeTo(20,1);
        
    }, function () {
        $("#Canada").fadeTo(20,0.4);
        $("#CanadaPopUp").fadeToggle(20);
     });
    
    $("#UnitedArabEmirates").fadeTo(20,0.4);
      $("#UnitedArabEmiratesPopUp").hide();
     $("#UnitedArabEmirates").hover(function() {
    $("#UnitedArabEmiratesPopUp").fadeToggle(20);
        $("#UnitedArabEmirates").fadeTo(20,1);
        
    }, function () {
        $("#UnitedArabEmirates").fadeTo(20,0.4);
        $("#UnitedArabEmiratesPopUp").fadeToggle(20);
     });
    
    
      $("#Colombia").fadeTo(20,0.4);
       $("#ColombiaPopUp").hide();
     $("#Colombia").hover(function() {
    $("#ColombiaPopUp").fadeToggle(20);
        $("#Colombia").fadeTo(20,1);
        
    }, function () {
        $("#Colombia").fadeTo(20,0.4);
        $("#ColombiaPopUp").fadeToggle(20);
     });
    
    
       $("#France").fadeTo(20,0.4);
       $("#FrancePopUp").hide();
     $("#France").hover(function() {
       $("#FrancePopUp").fadeToggle(20);
        $("#France").fadeTo(20,1);
        
    }, function () {
        $("#France").fadeTo(20,0.4);
        $("#FrancePopUp").fadeToggle(20);
     });
    
    
    $("#Turkey").fadeTo(20,0.4);
       $("#TurkeyPopUp").hide();
     $("#Turkey").hover(function() {
      $("#TurkeyPopUp").fadeToggle(20);
        $("#Turkey").fadeTo(20,1);
        
    }, function () {
        $("#Turkey").fadeTo(20,0.4);
        $("#TurkeyPopUp").fadeToggle(20);
    }); 

    
        $("#Philippines").fadeTo(20,0.4);
       $("#PhilippinesPopUp").hide();
     $("#Philippines").hover(function() {
     $("#PhilippinesPopUp").fadeToggle(20);
        $("#Philippines").fadeTo(20,1);
        
    }, function () {
        $("#Philippines").fadeTo(20,0.4);
        $("#PhilippinesPopUp").fadeToggle(20);
    }); 
    

     $("#Thai").fadeTo(20,0.4);
       $("#ThaiPopUp").hide();
     $("#Thai").hover(function() {
    $("#ThaiPopUp").fadeToggle(20);
        $("#Thai").fadeTo(20,1);
        
    }, function () {
        $("#Thai").fadeTo(20,0.4);
        $("#ThaiPopUp").fadeToggle(20);
    }); 
    
    
     $("#Japan").fadeTo(20,0.4);
       $("#JapanPopUp").hide();
     $("#Japan").hover(function() {
       $("#JapanPopUp").fadeToggle(20);
        $("#Japan").fadeTo(20,1);
        
    }, function () {
        $("#Japan").fadeTo(20,0.4);
        $("#JapanPopUp").fadeToggle(20);
    }); 
    
    $("#Russia").fadeTo(20,0.4);
       $("#RussiaPopUp").hide();
     $("#Russia").hover(function() {
      $("#RussiaPopUp").fadeToggle(20);
        $("#Russia").fadeTo(20,1);
        
    }, function () {
        $("#Russia").fadeTo(20,0.4);
        $("#RussiaPopUp").fadeToggle(20);
    }); 
    
    
    $("#Indonesia").fadeTo(20,0.4);
       $("#IndonesiaPopUp").hide();
     $("#Indonesia").hover(function() {
         $("#IndonesiaPopUp").fadeToggle(20);
        $("#Indonesia").fadeTo(20,1);
        
    }, function () {
        $("#Indonesia").fadeTo(20,0.4);
        $("#IndonesiaPopUp").fadeToggle(20);
    }); 
    
    

    $("#Costa_Rica").fadeTo(20,0.4);
       $("#CostaRicaPopUp").hide();
     $("#Costa_Rica").hover(function() {
          $("#CostaRicaPopUp").fadeToggle(20);
        $("#Costa_Rica").fadeTo(20,1);
        
    }, function () {
        $("#Costa_Rica").fadeTo(20,0.4);
        $("#CostaRicaPopUp").fadeToggle(20);
    }); 
    

    $("#Kenya").fadeTo(20,0.4);
       $("#KenyaPopUp").hide();
     $("#Kenya").hover(function() {
         $("#KenyaPopUp").fadeToggle(20);
        $("#Kenya").fadeTo(20,1);
        
    }, function () {
        $("#Kenya").fadeTo(20,0.4);
        $("#KenyaPopUp").fadeToggle(20);
    }); 
    

    $("#Morocco").fadeTo(20,0.4)
       $("#MoroccoPopUp").hide();
     $("#Morocco").hover(function() {
            $("#MoroccoPopUp").fadeToggle(20);
        $("#Morocco").fadeTo(20,1);
        
    }, function () {
        $("#Morocco").fadeTo(20,0.4);
        $("#MoroccoPopUp").fadeToggle(20);
    }); 
    

    $("#Peru").fadeTo(20,0.4);
       $("#PeruPopUp").hide();
     $("#Peru").hover(function() {
             $("#PeruPopUp").fadeToggle(20);
        $("#Peru").fadeTo(20,1);
        
    }, function () {
        $("#Peru").fadeTo(20,0.4);
        $("#PeruPopUp").fadeToggle(20);
    }); 
    
    

    $("#CzechRep").fadeTo(20,0.4);
       $("#CzechRepPopUp").hide();
     $("#CzechRep").hover(function() {
             $("#CzechRepPopUp").fadeToggle(20);
        $("#CzechRep").fadeTo(20,1);
        
    }, function () {
        $("#CzechRep").fadeTo(20,0.4);
        $("#CzechRepPopUp").fadeToggle(20);
    }); 

    
    $("#Qatar").fadeTo(20,0.4);
       $("#QatarPopUp").hide();
     $("#Qatar").hover(function() {
              $("#QatarPopUp").fadeToggle(20);
        $("#Qatar").fadeTo(20,1);
        
    }, function () {
        $("#Qatar").fadeTo(20,0.4);
        $("#QatarPopUp").fadeToggle(20);
    }); 
    

    $("#Norway").fadeTo(20,0.4);
       $("#NorwayPopUp").hide();
     $("#Norway").hover(function() {
        $("#NorwayPopUp").fadeToggle(20);
        $("#Norway").fadeTo(20,1);
        
    }, function () {
        $("#Norway").fadeTo(20,0.4);
        $("#NorwayPopUp").fadeToggle(20);
    }); 

    $("#Argentina").fadeTo(20,0.4);
       $("#ArgentinaPopUp").hide();
     $("#Argentina").hover(function() {
       $("#ArgentinaPopUp").fadeToggle(20);
        $("#Argentina").fadeTo(20,1);
        
    }, function () {
        $("#Argentina").fadeTo(20,0.4);
        $("#ArgentinaPopUp").fadeToggle(20);
    }); 

    
     $("#Austria").fadeTo(20,0.4);
       $("#AustriaPopUp").hide();
     $("#Austria").hover(function() {
        $("#AustriaPopUp").fadeToggle(20);
        $("#Austria").fadeTo(20,1);
        
    }, function () {
        $("#Austria").fadeTo(20,0.4);
        $("#AustriaPopUp").fadeToggle(20);
    }); 


    $("#Singapore").fadeTo(20,0.4);
       $("#SingaporePopUp").hide();
     $("#Singapore").hover(function() {
            $("#SingaporePopUp").fadeToggle(20);
        $("#Singapore").fadeTo(20,1);
        
    }, function () {
        $("#Singapore").fadeTo(20,0.4);
        $("#SingaporePopUp").fadeToggle(20);
    }); 
    

    $("#Egypt").fadeTo(20,0.4);
       $("#EgyptPopUp").hide();
     $("#Egypt").hover(function() {
            $("#EgyptPopUp").fadeToggle(20);
        $("#Egypt").fadeTo(20,1);
        
    }, function () {
        $("#Egypt").fadeTo(20,0.4);
        $("#EgyptPopUp").fadeToggle(20);
    }); 

    $("#SouthAfrica").fadeTo(20,0.4);
       $("#SouthAfricaPopUp").hide();
     $("#SouthAfrica").hover(function() {
            $("#SouthAfricaPopUp").fadeToggle(20);
        $("#SouthAfrica").fadeTo(20,1);
        
    }, function () {
        $("#SouthAfrica").fadeTo(20,0.4);
        $("#SouthAfricaPopUp").fadeToggle(20);
    }); 
    

    $("#Switzerland").fadeTo(20,0.4);
       $("#SwitzerlandPopUp").hide();
     $("#Switzerland").hover(function() {
            $("#SwitzerlandPopUp").fadeToggle(20);
        $("#Switzerland").fadeTo(20,1);
        
    }, function () {
        $("#Switzerland").fadeTo(20,0.4);
        $("#SwitzerlandPopUp").fadeToggle(20);
    }); 
    

    $("#Nigeria").fadeTo(20,0.4);
       $("#NigeriaPopUp").hide();
     $("#Nigeria").hover(function() {
            $("#NigeriaPopUp").fadeToggle(20);
        $("#Nigeria").fadeTo(20,1);
        
    }, function () {
        $("#Nigeria").fadeTo(20,0.4);
        $("#NigeriaPopUp").fadeToggle(20);
    }); 

     $("#SaudiArabia").fadeTo(20,0.4);
       $("#SaudiArabiaPopUp").hide();
     $("#SaudiArabia").hover(function() {
            $("#SaudiArabiaPopUp").fadeToggle(20);
        $("#SaudiArabia").fadeTo(20,1);
        
    }, function () {
        $("#SaudiArabia").fadeTo(20,0.4);
        $("#SaudiArabiaPopUp").fadeToggle(20);
    }); 

    $("#Spain").fadeTo(20,0.4);
       $("#SpainPopUp").hide();
     $("#Spain").hover(function() {
            $("#SpainPopUp").fadeToggle(20);
        $("#Spain").fadeTo(20,1);
        
    }, function () {
        $("#Spain").fadeTo(20,0.4);
        $("#SpainPopUp").fadeToggle(20);
    }); 
    

    $("#Mexico").fadeTo(20,0.4);
       $("#MexicoPopUp").hide();
     $("#Mexico").hover(function() {
           $("#MexicoPopUp").fadeToggle(20);
        $("#Mexico").fadeTo(20,1);
        
    }, function () {
        $("#Mexico").fadeTo(20,0.4);
        $("#MexicoPopUp").fadeToggle(20);
    }); 
    

    $("#SouthKorea").fadeTo(20,0.4);
       $("#SouthKoreaPopUp").hide();
     $("#SouthKorea").hover(function() {
          $("#SouthKoreaPopUp").fadeToggle(20);
        $("#SouthKorea").fadeTo(20,1);
        
    }, function () {
        $("#SouthKorea").fadeTo(20,0.4);
        $("#SouthKoreaPopUp").fadeToggle(20);
    }); 
    
    

    $("#Italy").fadeTo(20,0.4);
       $("#ItalyPopUp").hide();
     $("#Italy").hover(function() {
          $("#ItalyPopUp").fadeToggle(20);
        $("#Italy").fadeTo(20,1);
        
    }, function () {
        $("#Italy").fadeTo(20,0.4);
        $("#ItalyPopUp").fadeToggle(20);
    }); 
    

    $("#Brazil").fadeTo(20,0.4);
       $("#BrazilPopUp").hide();
     $("#Brazil").hover(function() {
          $("#BrazilPopUp").fadeToggle(20);
        $("#Brazil").fadeTo(20,1);
        
    }, function () {
        $("#Brazil").fadeTo(20,0.4);
        $("#BrazilPopUp").fadeToggle(20);
    }); 
    

    $("#UK").fadeTo(20,0.4);
       $("#UKPopUp").hide();
     $("#UK").hover(function() {
         $("#UKPopUp").fadeToggle(20);
        $("#UK").fadeTo(20,1);
        
    }, function () {
        $("#UK").fadeTo(20,0.4);
        $("#UKPopUp").fadeToggle(20);
    }); 
    

    $("#Germany").fadeTo(20,0.4);
       $("#GermanyPopUp").hide();
     $("#Germany").hover(function() {
         $("#GermanyPopUp").fadeToggle(20);
        $("#Germany").fadeTo(20,1);
        
    }, function () {
        $("#Germany").fadeTo(20,0.4);
        $("#GermanyPopUp").fadeToggle(20);
    }); 

});

